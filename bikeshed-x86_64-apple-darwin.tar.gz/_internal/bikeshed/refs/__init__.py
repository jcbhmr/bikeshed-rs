from .external import ExternalRefsGroup, ExternalRefsManager, ExternalRefsSpec
from .manager import ReferenceManager
from .source import MethodVariant, MethodVariants, RefSource
from .wrapper import RefWrapper
