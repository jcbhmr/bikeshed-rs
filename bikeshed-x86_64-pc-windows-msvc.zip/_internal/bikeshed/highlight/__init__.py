from .highlight import addSyntaxHighlighting
