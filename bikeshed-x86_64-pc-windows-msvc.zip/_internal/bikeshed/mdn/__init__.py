from .mdnspeclinks import addMdnPanels
