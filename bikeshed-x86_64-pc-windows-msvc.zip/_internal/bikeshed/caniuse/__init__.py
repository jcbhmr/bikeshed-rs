from .caniuse import CanIUseManager, addCanIUsePanels
