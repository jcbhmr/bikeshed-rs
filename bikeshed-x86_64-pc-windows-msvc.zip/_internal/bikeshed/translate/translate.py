from __future__ import annotations


def _(input: str) -> str:
    return input
