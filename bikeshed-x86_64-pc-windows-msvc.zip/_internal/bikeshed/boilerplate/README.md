Boilerplate Files Have Moved
============================

If you're here to modify or create a boilerplate file,
they've moved to a separate [bikeshed-boilerplate](https://github.com/speced/bikeshed-boilerplate) project,
to make it easier to update boilerplates
without having to roll new pip releases for Bikeshed.

Please file any PRs there.